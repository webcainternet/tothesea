<?php
$_['text_title'] 		= 'PagSeguro';
$_['text_information'] 	= 'Ao clicar no botão abaixo, você será redirecionado para o site do PagSeguro para efeturar o pagamento. Ao concluir o pagamento você retornará automaticamente para a loja.';
$_['text_wait']         = 'Por favor, aguarde!';
$_['button_confirm_pagseguro'] = 'Confirmar e ir para o PagSeguro';
$_['text_extra_amount']	= 'Frete e Taxas';
?>