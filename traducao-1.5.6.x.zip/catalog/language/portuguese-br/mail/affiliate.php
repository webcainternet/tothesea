<?php
// Text
$_['text_subject']  = '%s - Programa de Afiliados';
$_['text_welcome']  = 'Obrigado por aderir ao %s Programa de Afiliados!';
$_['text_approval'] = 'Sua conta precisa ser aprovada para que você possa acessar seus dados no Programa de Afiliados. Assim que sua conta for aprovada você poderá acessar usando seu endereço de e-mail e sua senha ao vistar nossa loja, ou através do seguinte link:';
$_['text_services'] = 'Ao acessar sua conta você será capaz de gerar os códigos de monitoramento, acessar pagamentos de comissões e controlar e editar as informações de sua conta.';
$_['text_thanks']   = 'Atenciosamente,';
?>