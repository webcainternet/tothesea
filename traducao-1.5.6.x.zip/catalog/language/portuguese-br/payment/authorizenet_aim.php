<?php
// Text
$_['text_title']           = 'Cartão de Crédito/Débito (Authorize.Net)';
$_['text_credit_card']     = 'Detalhes do Cartão de Crédito';
$_['text_wait']            = 'Aguarde!';

// Entry
$_['entry_cc_owner']       = 'Titular da Conta:';
$_['entry_cc_number']      = 'Número do Cartão:';
$_['entry_cc_expire_date'] = 'Válido até:';
$_['entry_cc_cvv2']        = 'Código de segurança do cartão (CVV2):';
?>