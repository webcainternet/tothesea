<?php
// Text
$_['text_title']       = 'Depósito ou Transferência Bancária';
$_['text_instruction'] = 'Instruções para o pagamento por depósito ou transferência bancária';
$_['text_description'] = 'Deposite ou transfira o valor total do pedido para:';
$_['text_payment']     = 'Após o depósito ou transferência, envie a cópia do comprovante respondendo o e-mail com dados do pedido que você receberá.';
?>