<?php
// Entry
$_['text_title']     = 'Cartão de Crédito / Débito (Google Checkout)';

// Error
$_['error_shipping'] = 'Atenção: Frete é obrigatório!';
?>