<?php
// Text
$_['text_title']       = 'Cartão de Crédito/Débito (SagePay)';
$_['text_description'] = 'Itens em %s - Nº do pedido: %s';
?>