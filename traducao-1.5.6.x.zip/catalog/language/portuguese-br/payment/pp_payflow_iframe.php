<?php
// Text
$_['text_title']             = 'Cartão de Crédito ou Débito';
$_['text_secure_connection'] = 'Acessando conexão segura...';

// Error
$_['error_connection']       = 'Não foi possível conectar ao PayPal. Entre em contato com o suporte da loja e solicite assistência para escolher um método de pagamento diferente.';
?>