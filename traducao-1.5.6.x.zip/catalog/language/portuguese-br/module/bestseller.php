<?php
// Heading 
$_['heading_title'] = 'Mais Vendidos';

// Text
$_['text_reviews']  = 'Baseado em %s comentários.'; 
?>