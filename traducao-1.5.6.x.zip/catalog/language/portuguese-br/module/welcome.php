<?php
$_['heading_title'] = '%s';
?>