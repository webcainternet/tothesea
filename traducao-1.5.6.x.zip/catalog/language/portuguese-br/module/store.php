<?php
// Heading 
$_['heading_title'] = 'Lojas';

// Text
$_['text_default']  = 'Padrão';
$_['text_store']    = 'Escolha a loja.';
?>