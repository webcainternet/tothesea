<?php
// Heading 
$_['heading_title'] = 'Ofertas Especiais';

// Text
$_['text_reviews']  = 'Baseado em %s coment�rios.'; 
?>