<?php
// Text
$_['text_language'] = 'Idioma';
?>