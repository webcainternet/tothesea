<?php
// Heading 
$_['heading_title']        = 'Meu Carrinho';

// Text
$_['text_items']           = '%s item(ns) - %s';
$_['text_empty']           = 'Você ainda não adicionou produtos.';
$_['text_cart']            = 'Ver Carrinho';
$_['text_checkout']        = 'Finalizar Pedido';
$_['text_payment_profile'] = 'Assinatura';
?>