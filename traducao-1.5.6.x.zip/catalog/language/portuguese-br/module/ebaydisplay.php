<?php
$_['heading_title'] = 'Em nossa loja no eBay';
?>