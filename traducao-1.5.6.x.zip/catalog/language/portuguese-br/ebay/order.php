<?php
//Order totals
$_['lang_shipping']     = 'Frete';
$_['lang_discount']     = 'Desconto';
$_['lang_tax']          = 'Imposto';
$_['lang_subtotal']     = 'Sub-total';
$_['lang_total']        = 'Total';
?>