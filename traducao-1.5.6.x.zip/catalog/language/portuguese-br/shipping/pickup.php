<?php
// Text
$_['text_title']       = 'Retirada na Loja';
$_['text_description'] = 'Nenhum valor será cobrado.';
?>