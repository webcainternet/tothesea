<?php
// Text
$_['text_title']  = 'Frete por Peso';
$_['text_weight'] = 'Peso Total:';
?>