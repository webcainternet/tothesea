<?php
// Text
$_['text_title']       = 'Frete por Itens';
$_['text_description'] = 'Valor total baseado na quantidade de itens do pedido.';
?>