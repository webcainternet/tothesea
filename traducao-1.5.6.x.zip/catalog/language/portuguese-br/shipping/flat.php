<?php
// Text
$_['text_title']       = 'Frete Fixo';
$_['text_description'] = 'Valor total para todo o pedido.';
?>