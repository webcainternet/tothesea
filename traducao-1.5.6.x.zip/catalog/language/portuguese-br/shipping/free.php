<?php
// Text
$_['text_title']       = 'Frete Grátis';
$_['text_description'] = 'Nenhum valor será cobrado.';
?>