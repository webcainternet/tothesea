<?php
// Text
$_['text_home']          = 'Principal';
$_['text_wishlist']      = 'Lista de Desejos (%s)';
$_['text_shopping_cart'] = 'Meu Carrinho';
$_['text_search']        = 'Busca';
$_['text_welcome']       = 'Olá, visitante. Acesse sua <a href="%s">conta</a> ou <a href="%s">cadastre-se</a>.';
$_['text_logged']        = 'Você acessou como <a href="%s">%s</a> <b>(</b> <a href="%s">Sair</a> <b>)</b>';
$_['text_account']       = 'Minha Conta';
$_['text_checkout']      = 'Finalizar Pedido';
?>