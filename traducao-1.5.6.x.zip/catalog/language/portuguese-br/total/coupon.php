<?php
// Heading 
$_['text_coupon'] = 'Cupom (%s)';
?>