<?php
$_['text_handling'] = 'Taxa de manuseio';
?>