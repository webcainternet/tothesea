<?php
// Heading 
$_['heading_title']        = 'Minha Conta';

// Text
$_['text_account']         = 'Painel de Afiliado';
$_['text_my_account']      = 'Informações da Conta';
$_['text_my_tracking']     = 'Meus Códigos';
$_['text_my_transactions'] = 'Minhas Indicações';
$_['text_edit']            = 'Alterar Conta';
$_['text_password']        = 'Alterar Senha';
$_['text_payment']         = 'Pagamento';
$_['text_tracking']        = 'Gerar Links';
$_['text_transaction']     = 'Indicações';
?>