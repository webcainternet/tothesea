<?php
// Heading 
$_['heading_title'] = 'Sair';

// Text
$_['text_message']  = '<p>Você saiu de sua conta no sistema de afiliados. Agora você pode sair da loja de maneira segura.</p>';
$_['text_account']  = 'Programa de Afiliados';
$_['text_logout']   = 'Sair';
?>