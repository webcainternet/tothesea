<?php
// Heading 
$_['heading_title']      = 'Meus Pontos de Fidelidade';

// Column
$_['column_date_added']  = 'Adicionado em';
$_['column_description'] = 'Descrição';
$_['column_points']      = 'Pontos';

// Text
$_['text_account']       = 'Minha Conta';
$_['text_reward']        = 'Pontos de Fidelidade';
$_['text_total']         = 'Seu número total de pontos de fidelidade é:';
$_['text_empty']         = 'Você ainda não tem nenhum ponto de fidelidade!';
?>