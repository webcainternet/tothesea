<?php
// Heading 
$_['heading_title']   = 'Meus Downloads';

// Text
$_['text_account']    = 'Minha Conta';
$_['text_downloads']  = 'Downloads';
$_['text_order']      = 'Pedido Nº:';
$_['text_date_added'] = 'Adicionado em:';
$_['text_name']       = 'Nome:';
$_['text_remaining']  = 'Restam:';
$_['text_size']       = 'Tamanho:';
$_['text_empty']      = 'Nenhum pedido de download foi registrado até o momento!';
?>