<?php
// Heading 
$_['heading_title']    = 'Gerenciador de Extensões';

// Text
$_['text_success']     = 'Extensão instalada com sucesso!';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para acessar o Gerenciador de Extensões!';
$_['error_upload']     = 'Upload obrigatório!';
$_['error_filetype']   = 'Tipo de arquivo inválido!';
?>