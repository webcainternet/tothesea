<?php
// Heading
$_['heading_title']		= 'Formas de Pagamento';

// Text
$_['text_install']		= 'Instalar';
$_['text_uninstall']	= 'Desinstalar';

// Column
$_['column_name']		= 'Forma de Pagamento';
$_['column_status']		= 'Situação';
$_['column_sort_order']	= 'Ordem de Exibição';
$_['column_action']		= 'Ação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar as formas de pagamento!';
?>