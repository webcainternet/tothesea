<?php
$_['lang_openbay_new']        = 'Criar Nova Lista';
$_['lang_openbay_edit']       = 'Visualizar/Editar';
$_['lang_openbay_fix']        = 'Corrgir Erros';
$_['lang_openbay_processing'] = 'Processando';

$_['lang_amazonus_saved']     = 'Atualizado (não carregado)';
$_['lang_amazon_saved']       = 'Atualizado (não carregado)';

$_['lang_markets']            = 'Mercados';
$_['lang_bulk_btn']           = 'Atualização em Massa no eBay';
$_['lang_bulk_amazon_btn']    = 'Atualização em Massa no Amazon EU';

$_['lang_marketplace']        = 'Mercado';
$_['lang_status']             = 'Situação';
$_['lang_option']             = 'Opção';
?>