<?php
$_['lang_btn_status']          = 'Alterar Situação';
$_['lang_order_channel']       = 'Canal de Pedidos';
$_['lang_confirmed']           = 'pedidos foram marcados';
$_['lang_no_orders']           = 'Não há pedidos selecionados para atualização';
$_['lang_confirm_title']       = 'Revisão de atualização de pedidos em massa';
$_['lang_confirm_change_text'] = 'Mudança de situação para';
$_['lang_column_addtional']    = 'Mais informações';
$_['lang_column_comments']     = 'Comentários';
$_['lang_column_notify']       = 'Notificações';
$_['lang_carrier']             = 'Transportadora';
$_['lang_tracking']            = 'Rastreamento';
$_['lang_other']               = 'Outra Transportadora';
$_['lang_refund_reason']       = 'Razão do Reemboldo';
$_['lang_refund_message']      = 'Mensagem de Reembolso';
$_['lang_update']              = 'Atualizar';
$_['lang_cancel']              = 'Cancelar';
$_['lang_e_ajax_1']            = 'Você deve digitar um motivo para o reembolso!';
$_['lang_e_ajax_2']            = 'Você deve digitar as informações do rastreamento!';
$_['lang_e_ajax_3']            = 'Você deve digitar outra transportadora para Amazon!';
$_['lang_title_order_update']  = 'Atualização de pedidos em massa';
?>