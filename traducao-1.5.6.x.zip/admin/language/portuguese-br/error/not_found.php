<?php
// Heading
$_['heading_title']  = 'Página não Encontrada!';

// Text
$_['text_not_found'] = 'A página que você tentou acessar não foi encontrada! Por favor, entre em contato conosco caso o problema não for resolvido.';
?>