<?php
// Heading
$_['heading_title']		 = 'Pagamento Grátis';

// Text
$_['text_payment']		 = 'Formas de Pagamento';
$_['text_success']		 = 'Módulo Pagamento Grátis modificado com sucesso!';

// Entry
$_['entry_order_status'] = 'Situação do Pedido:';
$_['entry_status']		 = 'Situação:';
$_['entry_sort_order']	 = 'Ordem de Exibição:';

// Error
$_['error_permission']	 = 'Atenção: Você não possui permissão para modificar o módulo Pagamento Grátis!';
?>