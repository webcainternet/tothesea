<?php
//Heading
$_['heading_title']                = 'eBay';

//Install actions
$_['text_install']                 = 'Instalar';
$_['text_edit']                    = 'Editar';
$_['text_uninstall']               = 'Desinstalar';

//Status
$_['text_enabled']                 = 'Habilitar';
$_['text_disabled']                = 'Desabilitar';

//Messages
$_['error_category_nosuggestions'] = 'Não foi possível carregar nenhuma categoria sugerida';
$_['lang_text_success']            = 'Você salvou as alterações na extensão eBay';
?>