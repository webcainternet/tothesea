<?php
$_['heading_title']  = 'OpenBay Pro';

$_['text_module']    = 'Módulos';
$_['text_installed'] = 'Módulo OpenBay Pro está instalado. Ele está disponível em Extensões->OpenBay Pro';
?>