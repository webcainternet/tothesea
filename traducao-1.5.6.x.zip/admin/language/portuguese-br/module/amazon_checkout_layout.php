<?php
// Heading
$_['heading_title']       = 'Botão Amazon Payments';

$_['text_module']         = 'Módulos';
$_['text_success']        = 'Módulo Botão Amazon Payments atualizado com sucesso!';
$_['text_content_top']    = 'Topo do Conteúdo';
$_['text_content_bottom'] = 'Rodapé do Conteúdo';
$_['text_column_left']    = 'Coluna da Esquerda';
$_['text_column_right']   = 'Coluna da Direita';

$_['entry_layout']        = 'Layout:';
$_['entry_position']      = 'Posição:';
$_['entry_status']        = 'Situação:';
$_['entry_sort_order']    = 'Ordem de Exibição:';

$_['error_permission']    = 'Atenção: Você não possui permissão para modificar o módulo Botão Amazon Payments!';
?>