<?php
// Heading
$_['heading_title']    = 'Vale Presentes';

// Text
$_['text_total']       = 'Finalização do Pedido';
$_['text_success']     = 'Módulo Vale Presentes modificado com sucesso!';

// Entry
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordem de Exibição:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o módulo Vale Presentes!';
?>